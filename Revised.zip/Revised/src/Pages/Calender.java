  package Pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Calender {
	static String Adate = "Aug 2020";
	static String Edate;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("https://www.redbus.in/");
		dr.findElement(By.xpath("//input[@id='onward_cal']")).click();
		Edate = dr.findElement(By.xpath("//div[@ id='ui-datepicker-div']")).getText();
		while(!Adate.equals(Edate))
		{
			dr.findElement(By.xpath("//span[@ class = 'ui-icon ui-icon-circle-triangle-w']")).click();
			Edate = dr.findElement(By.xpath("//div[@ class='ui-datepicker-title']")).getText();
		}
		List <WebElement> rb = dr.findElements(By.xpath("//table[@ class = 'ui-datepicker-calendar']//td"));
		for(WebElement w : rb)
		{
			String date = w.getText();
			if(date.equalsIgnoreCase("12"))
			{
				w.click();
				break;
			}
			
		}

	}

}
