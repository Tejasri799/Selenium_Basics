package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WrapsElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.collections.Lists;

/*import Tests.List;
import Tests.WebElement;

public class Datepick {
	System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
	WebDriver dr = new ChromeDriver();
	dr.get("http://redbus.in//");
	dr.findElement(By.xpath("//*[@class='fl icon-calendar_icon-new icon-onward-calendar icon']")).click();
	String Cdate=dr.findElement(By.xpath("//*[@id='rb-calendar_onward_cal']//following::td[1]")).getText();

	String a[]=date.split("-");
	String b[]=Cdate.split(" ");


	  while( !Cdate.equals(a[1]+" "+a[2]))
	   {
	dr.findElement(By.xpath("//*[@id='rb-calendar_onward_cal']//following::td[2]")).click();
	}
	 
	Lists r=dr.findElements(By.xpath("//*[@class='rb-monthTable first last']//following::td"));
	for(WrapsElement d:r)
	{
	String da=d.getText();
	if(da.equals(a[0]))
	{
	d.click();
	   break;
	}
	}
}
*/