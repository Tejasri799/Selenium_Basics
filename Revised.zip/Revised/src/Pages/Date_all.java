package Pages;

import java.util.List;

import javax.swing.text.Utilities;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import Library.Utilities2;

public class Date_all {
	Utilities2 obj;
	WebDriver dr;
	public  Date_all(WebDriver dr) 
	{
	this.dr = dr;
	obj = new Utilities2(dr);
	}
		static String Edate = "Aug 2020";
		String Adate;
		By click = By.xpath("//label[@class='db text-trans-uc']");
		By Month = By.xpath("//td[@class='monthTitle']");
		By Next = By.xpath("//td[@class='next']");
		By date = By.xpath("//div[@id='rb-calendar_onward_cal']");
		public void Read()
		{
			WebElement t =obj.EW(click,20);
			t.click();
		}
		public void Take()
		{
			WebElement t = obj.EW(Month,20);
			String s = t.getText();
			if(!Edate.equals(s))
			{
				dr.findElement(Next).click();
				s = dr.findElement(Month).getText();
				
						List<WebElement> all=dr.findElements(date);
				for(WebElement f:all)
				{
					String date=f.getText();
					if(date.equalsIgnoreCase("11"))
					{
						f.click();
						break;
					}
					
					}
				}
				
			}
}
	