package Pages;

import org.openqa.selenium.By;

public class Page1
{

	By Adate = By.xpath("//input[@id='onward_cal']");
	

}
