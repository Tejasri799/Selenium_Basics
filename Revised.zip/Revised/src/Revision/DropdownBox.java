package Revision;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class DropdownBox {
	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("https://demoqa.com//droppable//");
		dr.manage().window().maximize();
		Actions builder = new Actions(dr);
		WebElement from= dr.findElement(By.id("draggable"));
		WebElement to=dr.findElement(By.id("droppable"));
		builder.dragAndDrop(from,to).perform();
		String textTo=to.getText();
		System.out.println(textTo);
		if(textTo.equals("Dropped!"))
		{
			System.out.println("Pass");
		}
		else
		{
			System.out.println("Fail");
		}
	}

}
