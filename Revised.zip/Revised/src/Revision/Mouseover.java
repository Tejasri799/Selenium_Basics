package Revision;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Mouseover {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("https://jpetstore.cfapps.io/login");
		dr.manage().window().maximize();
		WebElement w=dr.findElement(By.xpath("//input[@name='username']"));
		WebElement w1=dr.findElement(By.xpath("//div[@id='Catalog']//child::a"));
		Actions z=new Actions(dr);
		z.keyDown(w,Keys.SHIFT).sendKeys(w,"Anika").keyUp(w, Keys.SHIFT).build().perform();  //shift operation
		z.moveToElement(w1).build().perform();  //mouse over

		}

		}


