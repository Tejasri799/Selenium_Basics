package Tests;

import org.testng.annotations.Test;

import Library.Utilities2;

import org.testng.annotations.BeforeMethod;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;

public class NewTest extends Utilities2{
	public NewTest(WebDriver dr) {
		super(dr);
		// TODO Auto-generated constructor stub
	}

	static WebDriver dr;
	
  @Test
  public void f() {
  }
  @BeforeMethod
  public void beforeMethod() 
  {
	   
	  
  }

  @BeforeClass
  public void beforeClass() {
	  System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");
	  dr = new ChromeDriver();
	  dr.get("https://www.redbus.in/");
		
  }

}
