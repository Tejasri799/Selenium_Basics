package Library;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

//import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import Excel.Excel_1;

public class Utilities2 extends Excel_1
{
	static WebDriver dr;
	static int counter =1;
//	Logger log;
	
	/*public Utilities2(WebDriver dr)
	{
		this.dr = dr;
	//	log = Logger.getLogger("devpinoyLogger");
	}*/
	/*	public void Logg(String msg)
		{
			log.debug(msg);
			
		}*/
		
	/*public WebElement EW(By locator,int timeout)
	{
		WebElement u = null;
		try {
			WebDriverWait wait = new WebDriverWait(dr, timeout);
			u = wait.until(
					ExpectedConditions.visibilityOfElementLocated(locator)
					);
			System.out.println("Element Located");
			
		} catch(Exception u1)
		{
			System.out.println("Element not located"+u1);
		}
	
		return u;
	}
	public WebElement elementToBeCickable(By locator, int timeout)
	{
		try {
			WebDriverWait wait = new WebDriverWait(dr, timeout);
			WebElement element = wait.until(
					ExpectedConditions.elementToBeClickable(locator)
					);
			System.out.println("Element Located");
			return element;
		} catch (Exception e)
		{
		//	this.Logg("Exception Occured in ElementToBeClickable Method");
			System.out.println("Element not located" + e);
		}
		
		return null;
	}*/
	
	

/*public void Screenshot() {
	String path = "C:\\Users\\BLTuser.BLT0188\\Desktop\\Screenshots";
	String filename = counter + ".png";
		File f1 = ((TakesScreenshot)dr).getScreenshotAs(OutputType.FILE);
		File f2 = new File (path+filename);
		try
		{
			FileUtils.copyFile(f1,f2);
		}
		catch (IOException e)
		{
			//this.Logg("IOException occcured while taking screen shot");
			System.out.println("screen shot number : " + counter + "failed");
			e.printStackTrace();
		}
		counter ++;
	}  */
public WebDriver lb(String b,String URL)
{
	if(b.contains("Chrome"))	{
	
	System.setProperty("webdriver.chrome.driver", "src\\test\\resources\\Drivers\\chromedriver_v79.exe");
	dr = new ChromeDriver();
	
	}
	else if(b.contains("Firefox"))
	{
	System.setProperty("webdriver.gecko.driver", "geckodriver_v0.26.exe");
	 dr = new FirefoxDriver();
	  
	}
	
	dr.get("http://demowebshop.tricentis.com/login");
	dr.manage().window().maximize();
	dr.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);

	return dr;
	}

}




