package Automation;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class A2_BmandAm {
	@BeforeMethod
	public void bm(){
		System.out.println("Before Method");
	}
	@AfterMethod
	public void am(){
		System.out.println("After Method");
	}
  @Test
  public void t1() {
	  System.out.println("In test method 1");
  }
  @Test
  public void t2() {
	  System.out.println("In Test method 2");
  }
  @Test
  public void t3() {
	  System.out.println("In Test method 3");
  }
  
  }

