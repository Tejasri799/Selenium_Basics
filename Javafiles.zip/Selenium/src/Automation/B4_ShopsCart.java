package TestNG_Automation;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.AfterClass;

public class B4_ShopsCart {
	WebDriver dr;
	B4_2Products z;
	int i=0;
	int[] arr={3,5};
	 @BeforeClass
	  public void beforeClass() 
	 {
		z=new B4_2Products();
		z.LB();
		z.Login("standard_user", "secret_sauce");
	 }
	 @BeforeMethod
	  public void beforeMethod() 
	 {
		 
		 z.Add_product(arr[i]);
	  }
  @Test
  public void f()
  {
	  z.verify(1);
	  
  }
  @Test
  public void f1()
  {
	  z.verify(2);
	  
  }
  @AfterClass
  public void afterClass() 
  {
	  System.out.println("Product matched");
  }

}
