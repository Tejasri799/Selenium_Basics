package Automation;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;

public class B1_javaclassNG {
	WebDriver dr;
	B1_Java_cls jobj;

  @BeforeMethod
  public void beforeMethod() {
	  System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
		dr = new ChromeDriver();
		dr.get("https://www.saucedemo.com/");
		jobj = new B1_Java_cls(dr);
  }
		
		@Test
		public void t1(){
			jobj.Login("standard_user", "secret_sauce");
  }
		@AfterMethod
		public void AfterMethod(){
			dr.close();
		}
  }

 
  

