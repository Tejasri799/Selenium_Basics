package Automation;

import org.testng.annotations.Test;
public class A1_NewTest {
  @Test
  public void f() {
	  System.out.println("Test cases are executed");
	  
  }
  
}
