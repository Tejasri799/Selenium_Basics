package Automation;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class A3_MethodcallObj {
	Sample A;
  @BeforeMethod
  public void Bm1() {
 A= new Sample();
  }
  @Test
  public void f() {
	  A.Enter();
  }
}
