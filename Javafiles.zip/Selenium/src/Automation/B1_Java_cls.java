package Automation;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class B1_Java_cls {
	WebDriver dr;
	
	public void Login(String x,String y)
	{
	
		dr.findElement(By.xpath("//input[@id='user-name']")).sendKeys(x);
		dr.findElement(By.xpath("//input[@id='Password']")).sendKeys(y);
		dr.findElement(By.xpath("//input[@class='btn_action']")).click();
	}
	public B1_Java_cls(WebDriver obj){
		this.dr=obj;
	}

}
