package Automation;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class B3_MethodFive {
	WebDriver dr;
public void LB()
{
	System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
	dr=new ChromeDriver();
	dr.get("https://www.saucedemo.com/");
	}
public void Login(String x, String y)
{
	dr.findElement(By.xpath("//div[@class='login-box']//child::input[1]")).sendKeys(x);
	dr.findElement(By.xpath("//div[@class='login-box']//child::input[2]")).sendKeys(y);
	dr.findElement(By.xpath("//div[@class='login-box']//child::input[3]")).click();
}
public void Add_product(int i)
{
	dr.findElement(By.xpath("//div[@class='inventory_list']//div[1]//child::div[3]//child::button")).click();
}
public void verify()
{
	String p=dr.findElement(By.xpath("//div[@class='inventory_list']//div[1]//child::div[2]//child::a")).getText();
	System.out.println(p);
	String c=dr.findElement(By.xpath("//div[@class='inventory_list']//div[1]//child::div[3]//child::div")).getText();
	String d=c.substring(0,1);
	System.out.println(c);
	dr.findElement(By.xpath("//div[@class='shopping_cart_container']//child::a")).click();
	String p1=dr.findElement(By.xpath("//div[@ class='inventory_item_name']")).getText();
	String c1=d+dr.findElement(By.xpath("//div[@ class='inventory_item_price']")).getText();
	int q=p1.compareTo(p);
	int r=c1.compareTo(c);
	if(q==0)
	{
		System.out.println("Product names are matched");
	}
	else
	{
		System.out.println("Product names are not matched");
	}
	if(r==0)
	{
		System.out.println("costs are matched");
	}
	else
	{
		System.out.println("Costs are not matched");
	}
}
public void Add_info()
{
	dr.findElement(By.xpath("//div[@ class='cart_footer']//child::a[2]")).click();
	dr.findElement(By.xpath("//div[@ class='checkout_info']//child::input[1]")).sendKeys("Tejasri");
	dr.findElement(By.xpath("//div[@ class='checkout_info']//child::input[2]")).sendKeys("Reddy");
	dr.findElement(By.xpath("//div[@ class='checkout_info']//child::input[3]")).sendKeys("517501");
	dr.findElement(By.xpath("//div[@ class='checkout_buttons']//following::input")).click();
	dr.findElement(By.xpath("//div[@ class='cart_item_label']//child::a")).getText();
	dr.findElement(By.xpath("//div[@ class='cart_item_label']//child::div[2]")).getText();
}
}
	


