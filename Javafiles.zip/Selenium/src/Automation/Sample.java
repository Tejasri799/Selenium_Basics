package Automation;

public class Sample {
	public void Enter(){
		System.out.println("Login Successfull");
	}

}
