package Automation;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.AfterClass;

public class B3_ShopCart {
	B3_MethodFive z;
	 @BeforeClass
	  public void beforeClass() 
	 {
		z=new B3_MethodFive();
		z.LB();
		z.Login("standard_user", "secret_sauce");
	 }
	 @BeforeMethod
	  public void beforeMethod() 
	 {
		 z.Add_product(1);
	  }
  @Test
  public void f()
  {
	  z.verify();
	  z.Add_info();
  }
  @AfterClass
  public void afterClass() 
  {
	  System.out.println("Product matched");
  }

}
