package WEBDRIVER_BASICS;

	import org.openqa.selenium.By;
	import org.openqa.selenium.WebDriver;
//	import org.openqa.selenium.WebElement;
	import org.openqa.selenium.chrome.ChromeDriver;

	import java.util.Scanner;

	public class WebElements {

	public static void main(String[] args) {
	// TODO Auto-generated method stub
	Scanner s4= new Scanner(System.in);
	System.out.println("enetr the number");
	int p=s4.nextInt();
	System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
	WebDriver dr= new ChromeDriver();
	String k="teju3tejasri@gmail.com";
	dr.get("http://demowebshop.tricentis.com");
	dr.findElement(By.xpath("//div[@class='header-links']//child::li[2]")).click();
	dr.findElement(By.id("Email")).sendKeys("teju3tejasri@gmail.com");
	dr.findElement(By.id("Password")).sendKeys("Passion@1997");
	dr.findElement(By.xpath("//input[@class='button-1 login-button']")).click();
	dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[1]/div[1]/div[2]/ul/li[2]/a")).click();
	dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[1]/div[1]/div[2]/ul/li[2]/ul/li[3]/a")).click();
	String s= dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).getText();
	//String s1=dr.findElement(By.xpath("//div[@class='validation-summary-errors']//child::span")).getText();
	//System.out.println(s1);
	//String s2=dr.findElement(By.xpath("//div[@class='validation-summary-errors']//child::li")).getText();
	//System.out.println(s2);
	String link="//div[@class='product-grid']//child::div["+p+"]";
	String s3=dr.findElement(By.xpath(link)).getText();
	System.out.println(s3);
	int k1=p;
	String link2="//div[@class='item-box']["+k1+"]//child::input";
	dr.findElement(By.xpath(link2)).click();

	dr.findElement(By.xpath("//div[@class='header-links']//child::li[3]")).click();
	dr.findElement(By.xpath("//td[@class='remove-from-cart']//child::input")).click();
	dr.findElement(By.xpath("//div[@class='common-buttons']//child::input")).click();
	int m= s.compareTo(k);
//	if(m==0){
//	System.out.println("pass");
//	}else{
//	System.out.println("fail");
//	}
	}
	}
	




