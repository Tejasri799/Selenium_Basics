package WEBDRIVER_BASICS;

		import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;

		import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.chrome.ChromeDriver;

		public class Comparexpaths {

		

				public static void main(String[] args) {
				String p1="",p2="",cost1="",cost2="";
				System.setProperty("webdriver.chrome.driver", "chromedriver_V79.exe");
				WebDriver dr=new ChromeDriver();
				dr.get("https://www.saucedemo.com/");
				try
				{
				dr.findElement(By.xpath("//div[@class='login-box']//child::input[1]")).sendKeys("standard_user");
				dr.findElement(By.xpath("//div[@class='login-box']//child::input[2]")).sendKeys("secret_sauce");
				dr.findElement(By.xpath("//div[@class='login-box']//child::input[3]")).click();
				dr.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
				p1=dr.findElement(By.xpath("//div[@class='inventory_list']//following::div[@class='inventory_item_name'][1]")).getText();
				p2=dr.findElement(By.xpath("//div[@class='inventory_list']//following::div[@class='inventory_item_name'][2]")).getText();
				cost1=dr.findElement(By.xpath("//div[@class='inventory_list']//following::div[@class='inventory_item_price'][1]")).getText();
				cost2=dr.findElement(By.xpath("//div[@class='inventory_list']//following::div[@class='inventory_item_price'][2]")).getText();

				System.out.println(p1);
				System.out.println(p2);
				System.out.println(cost1);
				System.out.println(cost2);
				dr.findElement(By.xpath("//div[@class='inventory_list']//following::button[1]")).click();
				dr.findElement(By.xpath("//div[@class='inventory_list']//following::button[2]")).click();

				dr.findElement(By.xpath("//div[@class='shopping_cart_container']//child::a[1]")).click();
				dr.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
				}
				catch(WebDriverException e)
				{
					System.out.println("An Exceptional Case : ");
				}
				catch(NoSuchElementException e)
				{
					System.out.println("getting Errors");
				}
				String a_p1=dr.findElement(By.xpath("//div[@class='cart_list']//following::div[@class='inventory_item_name'][1]")).getText();
				String a_p2=dr.findElement(By.xpath("//div[@class='cart_list']//following::div[@class='inventory_item_name'][2]")).getText();
				String a_cost1=dr.findElement(By.xpath("//div[@class='cart_list']//following::div[@class='inventory_item_price'][1]")).getText();
				String a_cost2=dr.findElement(By.xpath("//div[@class='cart_list']//following::div[@class='inventory_item_price'][2]")).getText();

				if(p1.equals(a_p1)&& p2.equals(a_p2))
				System.out.println("Products names are matched");
				else
				System.out.println("Products names are not matched");
				if(cost1.substring(1).equals(a_cost1)&&cost2.substring(1).equals(a_cost2))
				System.out.println("Products costs are matched");
				else
				System.out.println("Products costs are not matched");
				}
			}

	
				

					