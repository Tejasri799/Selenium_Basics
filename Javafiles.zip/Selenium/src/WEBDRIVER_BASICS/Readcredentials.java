package WEBDRIVER_BASICS;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Readcredentials {

	public String getExcel(String filename,int r, int c, String sheet)
	{
		String s = null;
		File f = new File(filename);
				try
				{
					FileInputStream fis = new FileInputStream(f);
					XSSFWorkbook wb = new XSSFWorkbook(fis);
					XSSFSheet sh = wb.getSheet(sheet);
					XSSFRow r1 = sh.getRow(r);
					XSSFCell c1 = r1.getCell(c);
					 s = c1.getStringCellValue();
					System.out.println(s);    
				}
					catch (FileNotFoundException e) 
					{
						e.printStackTrace();
					}
					catch (IOException e)
					{
						e.printStackTrace();
					}
				return s;		
	}
	public void Login(String s1, String s2)
	{
		System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com");
		dr.findElement(By.xpath("//div[@ class = 'header-links']//child::li[2]")).click();
		dr.findElement(By.xpath("//div[@ class = 'inputs']//input[@ class= 'email']")).sendKeys(s1);
		dr.findElement(By.xpath("//div[@ class = 'inputs']//input[@ class= 'password']")).sendKeys(s2);
		dr.findElement(By.xpath("//input[@class='button-1 login-button']")).click();
	}
	
		public static void main(String[] args) {
				
				// TODO Auto-generated method stub
			Readcredentials z = new Readcredentials();
			String y = z.getExcel("C:\\Users\\BLTuser.BLT0188\\Desktop\\Tezoo.xlsx",0,0,"Sheet1");
			String y1 = z.getExcel("C:\\Users\\BLTuser.BLT0188\\Desktop\\Tezoo.xlsx",0,1,"Sheet1");
					z.Login(y, y1);
		}
}
						
	
				
					
				
				
				
				
				
				
			
		
