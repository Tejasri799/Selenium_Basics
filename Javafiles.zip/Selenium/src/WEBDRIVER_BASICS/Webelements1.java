package WEBDRIVER_BASICS;

import java.util.Scanner;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Webelements1 {
	public static void main(String[] args) 
	{
		System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
	WebDriver dr = new ChromeDriver();
	String t = "teju3tejasri@gmail.com";
	dr.get("http://demowebshop.tricentis.com");
	
	dr.findElement(By.xpath("//div[@ class='header-links']//child::li[2]")).click();
	dr.findElement(By.id("Email")).sendKeys("teju3tejasri@gmail.com");
	dr.findElement(By.id("Password")).sendKeys("Passion@1997");
	dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
	
	dr.findElement(By.xpath("//ul[@ class='top-menu']//child::li[2]")).click();
	dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div[2]/div[2]/div[1]/div[3]/div/h2/a")).click();
	Scanner sc = new Scanner(System.in);
	int m = sc.nextInt();
	System.out.println("Enter m ");
	dr.findElement(By.xpath("//div[@ data-productid='m']//following::input")).click();
	dr.findElement(By.xpath("//div[@ data-productid='m']//following::input")).getText();
	
	String s = dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).getText();
	

	int p = s.compareTo(t);
	if(p==0)
	{
		System.out.println("Pass");
	}
	else
	{
		System.out.println("Fail");
	}
	}

}
