package WEBDRIVER_BASICS;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Exceptiontest	 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
		WebDriver dr= new ChromeDriver();
		String xp1 ="/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a"; 
		dr.get("http://demowebshop.tricentis.com");
		WebElement we;
		WebDriverWait wt=new WebDriverWait(dr,20);
		we=wt.until(ExpectedConditions.elementToBeClickable(By.xpath(xp1)));
		we.click();
//		dr.findElement(By.xpath("//div[@ class='header-links1']")).click();

	}

}
