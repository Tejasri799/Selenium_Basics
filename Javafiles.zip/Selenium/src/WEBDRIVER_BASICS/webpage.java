package WEBDRIVER_BASICS;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class webpage {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("http://examples.codecharge.com/Store/Default.php");
		 String s=dr.getTitle();
		 System.out.println(s);
		 WebElement we=dr.findElement(By.xpath("//select[@name='category_id']"));
		 Select se=new Select(we);
		 se.selectByVisibleText("Databases");
		 dr.findElement(By.xpath("//input[@name='DoSearch']")).click();
		 dr.findElement(By.xpath("//a[@href='ProductDetail.php?product_id=1']")).click();
		String h= dr.findElement(By.xpath("//td[@valign='top']//child::h1")).getText();
		 System.out.println(h);
		 String h1=dr.findElement(By.xpath("//td[@valign='top']//child::td[2]")).getText();
		 dr.findElement(By.xpath("//input[@name='quantity']")).clear();
		 dr.findElement(By.xpath("//input[@name='quantity']")).sendKeys("2");
		 dr.findElement(By.xpath("//input[@name='Insert1']")).click();
		 String h2 =dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/table/tbody/tr/td/p")).getText();
		 if(h1==h2){
			 System.out.println(h1);
		 }
		 else{
			 System.out.println(h2);
		 }
	}

}
