package WEBDRIVER_BASICS;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Login_inv {

	public String loginvalid(String s1, String s2) {
		System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com");
		dr.findElement(By.xpath("//div[@ class = 'header-links']//child::li[2]")).click();
		dr.findElement(By.id("Email")).sendKeys(s1);
		dr.findElement(By.id("Password")).sendKeys(s2);
		dr.findElement(By.xpath("//input[@class='button-1 login-button']")).click();
//		String s = dr.findElement(By.xpath("//div[@class='validation-summary-errors']//child::span")).getText();
//		String p = dr.findElement(By.xpath("//div[@class='validation-summary-errors']//child::li")).getText();
//		String r = s.concat(p);
		String r = dr.findElement(By.xpath("//div[@ class = 'inputs']//child::span")).getText();
		return r;
	}

public static void main(String[] args) {
	 Login_inv n = new  Login_inv();
	 //String x = "Login was unsuccessful. Please correct the errors and try again." + "The credentials provided are incorrect";
	 //String x = "Login was unsuccessful. Please correct the errors and try again." + "No customer account found";
	String x = "Please enter a valid email address.";
	 
	 //String s1 = n.loginvalid("Anika@gmail.com", " ");
	String s1 = n.loginvalid("tezooooo0", "");
	//String s1 = n.loginvalid("", "Passion@1997");
	//String s1 = n.loginvalid("", "");
	//String s1 = n.loginvalid("tezoo7991@gmail.com", " ");
	
	int m = x.compareTo(s1);
	if(m==0)
	{
		System.out.println("Pass");
	}
	else
	{
		System.out.println("Fail");
	}
}
}

