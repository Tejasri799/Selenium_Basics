package WEBDRIVER_BASICS;



import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;



public class AllExcel {

public String getExcel(String filename,int row,int col,String Sheet){
 String s1=null;
File f= new File(filename);
try {
FileInputStream f1= new FileInputStream(f);
   XSSFWorkbook w1=new XSSFWorkbook(f1);

   XSSFSheet s2= w1.getSheet(Sheet);
   XSSFRow r1= s2.getRow(row);
       
   XSSFCell c1= r1.getCell(col);
   
       
  s1= c1.getStringCellValue();

       
} catch (FileNotFoundException e) {
// TODO Auto-generated catch block
e.printStackTrace();
}
 catch (IOException e) {
// TODO Auto-generated catch block
e.printStackTrace();
}
return s1;

}
public void writeExcel(String filename1,int row,int col,String Sheet,String s){
String s1=null;
File f= new File(filename1);
try {
FileInputStream f1= new FileInputStream(f);
   XSSFWorkbook w1=new XSSFWorkbook(f1);

   XSSFSheet s2= w1.getSheet(Sheet);
   XSSFRow r1= s2.getRow(row);
       
   XSSFCell c1= r1.createCell(col);
c1.setCellValue(s);
FileOutputStream fos= new FileOutputStream(f);
w1.write(fos);
         
   
} catch (FileNotFoundException e) {
// TODO Auto-generated catch block
e.printStackTrace();
}
catch (IOException e) {
// TODO Auto-generated catch block
e.printStackTrace();
}


}
public String login(String s1, String s2){

System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");
WebDriver dr= new ChromeDriver();
dr.get("http://demowebshop.tricentis.com");
dr.findElement(By.xpath("//div[@class='header-links']//child::li[2]")).click();
dr.findElement(By.id("Email")).sendKeys(s1);
dr.findElement(By.id("Password")).sendKeys(s2);
dr.findElement(By.xpath("//input[@class='button-1 login-button']")).click();
String s3= dr.findElement(By.xpath("//div[@class='header-links']//child::li[1]")).getText();

return s3;
}
public static void main(String[] args) {

AllExcel g= new AllExcel();
String p = "C:\\Users\\BLTuser.BLT0188\\Desktop\\Tezoo.xlsx";
String t = "Sheet1";
int row;
for(row=1; row<=3; row++)
{

	String Test_result;

String s1=g.getExcel(p, row, 0, t);

String s2=g.getExcel(p, row, 1, t);

String actualemail=g.login(s1,s2);


g.writeExcel(p, row, 3, t,actualemail);
String s4=g.getExcel(p, row, 2, t);
int m=s1.compareTo(s4);
if(m==0){
Test_result="Pass";
}else{
Test_result="Fail";
}
g.writeExcel(p, row, 4, t,Test_result);
}
}
}