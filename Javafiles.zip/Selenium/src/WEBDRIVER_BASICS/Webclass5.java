package WEBDRIVER_BASICS;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;


public class Webclass5 {
	
	static String str;
	public static void extract()
	{
		int p = str.indexOf(":",1);
		int q = str.indexOf("A",1);
		int r = str.indexOf(":",13);
		
		String s = str.substring(p+2,q-1);
		String s1 = str.substring(r+2);
		System.out.println(s);
		System.out.println(s1);
	}
	
	public static void main(String[] args) {
		Webclass5 x = new Webclass5();
		System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("https://www.seleniumeasy.com/test/basic-radiobutton-demo.html");
	
		
		
		List rb1 = dr.findElements(By.name("gender"));
		((WebElement) rb1.get(1)).click();
		
		List rb2 = dr.findElements(By.name("ageGroup"));
		((WebElement) rb2.get(2)).click();
		
		dr.findElement(By.xpath("/html/body/div[2]/div/div[2]/div[2]/div[2]/button")).click();
		x.str = dr.findElement(By.className("groupradiobutton")).getText();
		System.out.println(x.str);
		x.extract();
	}
}

	
	


