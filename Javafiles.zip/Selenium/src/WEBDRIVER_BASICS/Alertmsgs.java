package WEBDRIVER_BASICS;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Alertmsgs {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("http://demo.guru99.com/test/delete_customer.php");
		dr.findElement(By.xpath("//input[@name='cusid']")).sendKeys("Tezoo");
		dr.findElement(By.xpath("//input[@name='submit']")).click();
		
			try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			Alert a = dr.switchTo().alert();
			String s =a.getText();
			System.out.println(s);
			a.accept();

			try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			Alert a1 = dr.switchTo().alert();
			String s1 =a.getText();
			System.out.println(s1);
			a1.accept(); 
		
		
	}

}
