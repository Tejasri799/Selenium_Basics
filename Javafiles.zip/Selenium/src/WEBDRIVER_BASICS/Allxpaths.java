package WEBDRIVER_BASICS;

		import org.openqa.selenium.By;
		import org.openqa.selenium.WebDriver;
		import org.openqa.selenium.chrome.ChromeDriver;

		public class Allxpaths {

			public static void main(String[] args) {
				// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver", "chromedriver_V79.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com");
		dr.findElement(By.xpath("//div[@class='header-links']//following::a[2]")).click();

		//text

		dr.findElement(By.xpath("//label[(text()='Email:')]"));
		dr.findElement(By.xpath("//label[(text()='Password:')]"));
		dr.findElement(By.xpath("//label[(text()='Remember me?')]"));

	/*	//text & contains

		dr.findElement(By.xpath("//label[contains(text(),'Email:')]"));
		dr.findElement(By.xpath("//label[contains(text(),'Password:')]"));
		dr.findElement(By.xpath("//label[contains(text(),'Remember me?')]"));

		//contains & attribute

		    dr.findElement(By.xpath("//input[contains(@id,'Email')]"));
		dr.findElement(By.xpath("//input[contains(@id,'Password')]"));
		dr.findElement(By.xpath("//input[contains(@value,'Log in')]"));

		//following & child

		dr.findElement(By.xpath("//input[@id,'Email')]"));
		dr.findElement(By.xpath("//input[@id,'Password')]"));
		dr.findElement(By.xpath("//input[@value,'Log in')]"));
		*/

		}
		} 

		
		
		

	

