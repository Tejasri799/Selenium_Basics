package WEBDRIVER_BASICS;



import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Webclass3 {
	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("https://www.seleniumeasy.com/test/basic-radiobutton-demo.html");
		
		/*java.util.List<WebElement> rb = dr.findElements(By.name("optradio"));
		((WebElement) rb.get(0)).click();*/
		
		
		List rb = findElements(By.name("optradio"));
		((WebElement) rb.get(0)).click();
	}

	private static List findElements(By name) {
		// TODO Auto-generated method stub
		return null;
	}

}
