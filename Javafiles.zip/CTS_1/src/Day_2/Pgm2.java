package Day_2;
import java.io.*;
public class Pgm2 {
	public static void main(String[] args) {
		int arr[]={50,65,85,26,54,58,55,21,90,75};
		int sum=0;
		for (int i=0; i<10; i++)
			
		{
			
			if(i%2==0)
			{
				if(arr[i]%2!=0)
				{
					sum=sum+arr[i];
					
				}
			}
				
			
		}
		System.out.println("sum is" +sum);
	}
}
			
		

	


