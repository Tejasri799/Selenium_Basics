package Day_2;

public class pgm9 { 
	public static void main(String[] args)
	{
		int matrix[][]={{25,-48,12},{-81,42,16},{48,-60,23},{4,-22,-51}};
    

    int[] result = new int[matrix.length];
    for (int i = 0; i < matrix.length; i++)
    {
     int maxNum = matrix[i][0];
     for (int j = 0; j < matrix[i].length; j++) 
     {
      if(maxNum < matrix[i][j])
      {
       maxNum = matrix[i][j];
      }
      result[i] = maxNum;
    }
     
   }
    
    for (int i = 0; i < result.length; i++)
    {
        System.out.println("Maximum element in row " + (i + 1) + ": " + result[i]);
    }
   }
}


