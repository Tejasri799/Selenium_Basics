package Day_2;

public class Pgm7 {
	public static void main(String[] args) {
		int a=10,b=0,c;
		int[] m = {1,3,5,6};
		try
		{
			System.out.println(m[5]);
			c=a/b;
		}
		catch(ArithmeticException ae)
		{
			System.out.println("Catch of ArithmeticException");
		}
		catch(ArrayIndexOutOfBoundsException aie)
		{
			System.out.println("Catch of ArrayIndexOutOfBoundsException");
		}
		System.out.println("Outside catch");
		
		
	}

}
