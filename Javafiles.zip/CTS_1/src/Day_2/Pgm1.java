package Day_2;
import java.io.*;
public class Pgm1 {
	public static void main(String[] args) {
		int marks[] ={95, 52, 89, 74, 95, 49, 87, 78, 55, 90};
		int sum=0; float avg;
		for(int i=0; i<10; i++)
			{
			sum=sum+marks[i];
            }
		    avg=sum/10;
			System.out.println(sum+ " "+avg);
			
			if(avg>=75)
			{
				System.out.println("First class with distinction");
			}
			if(avg>=65 && avg<75)
			{
				System.out.println("First class");
			}
			if(avg>=55 && avg<65)
			{
				System.out.println("Second Class");
			}
			else
			    System.out.println("Passed");
	}
}
			
	
			
			
		

