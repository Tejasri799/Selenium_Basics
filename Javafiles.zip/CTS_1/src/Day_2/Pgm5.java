package Day_2;

public class Pgm5 {
	public static void main(String[] args) {
	 int i,c=0;
	String s="I am Learning core java";
	for(i=0,c=0;i<s.length();i++)
	{
		char ch=s.charAt(i);
		if(ch==' ')
			c++;
	}
	System.out.println("The number of white spaces are : " +c);
	}

}



	
	
