package Day_3;

public class Calculator extends Library {
	public static void main(String[] args) {
		Calculator c = new Calculator();
		int d = c.add(3,5);
		System.out.println(d);
	}

}
