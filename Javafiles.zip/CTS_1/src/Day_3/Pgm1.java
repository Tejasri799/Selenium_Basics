package Day_3;
import java.util.Scanner;
public class Pgm1 {
	public static void main(String[] args) {
		System.out.println("Enter the characters : ");
		Scanner sc = new Scanner(System.in);
		char c = sc.next().charAt(0);
		int count = 0;
		while(c!= 'N' && c!= 'n')
		{
		if(c=='A' || c=='E' ||c== 'I' ||c=='O' ||c=='U' ||c=='a' ||c=='e' ||c=='i' ||c=='o' ||c=='u' )
		{
			count++;
		}
		c = sc.next().charAt(0);
		}
		System.out.println(count);
	}
}
	


