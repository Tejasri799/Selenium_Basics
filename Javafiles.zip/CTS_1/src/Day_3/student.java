package Day_3;

public class student {
		int id;
		String name;
		int selenium;
		int java;
		float avg;
		public void calc_avg()
		{
			avg=(selenium + java)/2.0f;
		}
	}
	