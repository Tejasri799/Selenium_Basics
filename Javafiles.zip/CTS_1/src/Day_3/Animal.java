package Day_3;

public class Animal {
	int height, weight, age;
	char c;
	String color;
public void display(){
	System.out.println(" height is " + height +" weight is " + weight +" age is "+ age +" color is " + color +"  c is" +c);
}
}

