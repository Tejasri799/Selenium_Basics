package Day_3;

public class College {
	public static void main(String[] args) {
		int i;
		float f;
		student lovely = new student();
		lovely.java = 90;
		lovely.selenium = 84;
		lovely.calc_avg();
		System.out.println(lovely.avg);
		
		student Anika = new student();
		Anika.java = 96;
		Anika.selenium = 98;
		Anika.calc_avg();
		System.out.println(Anika.avg);
	}
}
	