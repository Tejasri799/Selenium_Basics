package Collections;

public class Main {
	public static void main(String[] args) {
		ReadExcel e = new ReadExcel();
		e.getExcel("C:\\Users\\BLTuser.BLT0188\\Desktop\\EXCELSHEET1.xlsx",0,0,"Ishqbaaz","Shivaay");
	}
	

}
