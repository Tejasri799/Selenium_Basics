package Collections;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class Notepad {
	public static void main(String[] args) {
		try{
			FileInputStream fis = new FileInputStream("C:\\Users\\BLTuser.BLT0188\\Desktop\\New Text Document.txt");
			int i;
			while((i=fis.read())!=-1){
				System.out.println((char)i);
			}
			fis.close();
			FileOutputStream fos = new FileOutputStream("C:\\Users\\BLTuser.BLT0188\\Desktop\\New Text Document.txt");
			byte[] d="I am learning java".getBytes();
			fos.write(d);
			fos.close();
			
			}
		catch(IOException e){
			e.printStackTrace();
		}
	}
}
