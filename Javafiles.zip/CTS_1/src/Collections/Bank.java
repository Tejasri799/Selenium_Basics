package Collections;

public abstract class Bank {
	abstract float get_roi();
	public void show()
	{
		System.out.println("Bank Details");
	}

}
