package Collections;

public class Rectangle implements drawable {
	public void draw(){
		System.out.println("draw rectangle ");;
	}

}
