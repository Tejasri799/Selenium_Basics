package Collections;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadExcel {
	public String getExcel(String filename, int Row,int Column, String sheet,String s1){
		String s=null;
		File f =new File(filename);
		try{	
			FileInputStream fis = new FileInputStream(f);
			XSSFWorkbook wb = new XSSFWorkbook(fis);
			XSSFSheet sh = wb.getSheet(sheet);
			XSSFRow r = sh.getRow(Row);
			XSSFCell c = r.getCell(Column);
			String s0 = c.getStringCellValue();
			System.out.println(s0);
			XSSFSheet sh2 = wb.getSheet("Sheet2");
			XSSFRow r1 = sh2.getRow(Row);
			XSSFCell c1 = r1.getCell(Column);
			c1.setCellValue(s0);
			FileOutputStream fos = new FileOutputStream(f);
			wb.write(fos);
		}
		catch (FileNotFoundException e)
		{
			e.printStackTrace();
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
		return s;
		}
}