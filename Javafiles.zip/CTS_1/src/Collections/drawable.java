package Collections;

public interface drawable {
	void draw();

}
