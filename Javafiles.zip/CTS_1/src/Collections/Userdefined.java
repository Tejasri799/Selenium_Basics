package Collections;

import java.util.ArrayList;
import java.util.Collections;

public class Userdefined {
	public static void main(String[] args) {
		ArrayList<String> str_al = new ArrayList<String>();
		str_al.add("Gauri");
		
		str_al.add("Anika");
		str_al.add("Tejasri");
		str_al.add("Prudvi");
		
		System.out.println("Before Insertion : " + str_al);
		str_al.add(2,"Omkara");
		System.out.println("After Insertion : " + str_al);
		str_al.remove("Gauri");
		System.out.println("After Deletion : " + str_al);
		str_al.remove(1);
		System.out.println("After Deletion : " + str_al);
		for(String stu : str_al)
		{System.out.println(stu);
	}
	}

}
