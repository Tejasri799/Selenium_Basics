package Day_1;

import java.util.Scanner;

public class Pgm7 {
	public static void main(String[] args) {
	Scanner s = new Scanner(System.in);
	System.out.println("Enter range from 0 to");
		int n = s.nextInt();
		for(int i=0; i<=n; i++)
		{
			if(i%2==0)
			{
				System.out.println(i+ " ");
			}
		}
	}

}
