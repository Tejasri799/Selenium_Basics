package Day_1;

public class Pgm8 {
	public static void main(String[] args) {
		int sum=0;
		System.out.println("Enter a number");
	}

}
