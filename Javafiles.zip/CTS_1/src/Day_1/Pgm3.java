package Day_1;

public class Pgm3 {
	public static void main(String[] args) {
		int a=20, b=30;
		if(a>b)
		{
			System.out.println(a + "is greater than" +b);
			System.out.println("in then blk" );
		}
		else if (a==b)
			System.out.println(a+ "is equal to" +b);
		else
			System.out.println(a+ "is less than" +b);
	}

}
