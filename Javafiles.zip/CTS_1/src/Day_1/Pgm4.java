package Day_1;

public class Pgm4 {
	public static void main(String[] args) {
		int i=11,j=15,k=4;
		if(i<j){
			if(i<k)
			System.out.println(i + " is the smallest");
		}
		else if(j<k)
			System.out.println(j + " is the smallest");
		else
			System.out.println(k + " is the smallest");
	}

}
