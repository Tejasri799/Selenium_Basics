package Day_1;

public class Pgm1 {

	public static void main(String[] args) {
		int i=10;
		int j=20;
		System.out.println(i>j);
		System.out.println(i==10);
		
	}

}
