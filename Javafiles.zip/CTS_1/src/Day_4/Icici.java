package Day_4;

public class Icici extends Bank {
	public float get_Roi(){
		return 8.5f;
	}

}
