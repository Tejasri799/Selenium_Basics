package Day_4;

public class Test_bank {
	public static void main(String[] args) {
		Bank b;
		b = new Icici();
		System.out.println("ICICI ROI : "+ b.get_Roi());
		
		b = new Hdfc();
		System.out.println("HDFC ROI : "+ b.get_Roi());
	}

}
