package Day_4;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Getexcel1 {

	public static void main(String[] args) {
		File f = new File("C:\\Users\\BLTuser.BLT0188\\Desktop\\EXCELSHEET1.xlsx");
		try {
			FileInputStream fis = new FileInputStream(f);
			XSSFWorkbook wb = new XSSFWorkbook(fis);
			XSSFSheet sh = wb.getSheet("Sheet1");
			XSSFRow row = sh.getRow(0);
			XSSFCell cell = row.getCell(0);
			String s = cell.getStringCellValue();
			System.out.println(s);
			XSSFSheet sh2 = wb.getSheet("Sheet2");
			XSSFRow r = sh2.getRow(0);
			XSSFCell c = r.getCell(0);
						
			c.setCellValue(s);
			FileOutputStream fos = new FileOutputStream(f);
			wb.write(fos);
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
