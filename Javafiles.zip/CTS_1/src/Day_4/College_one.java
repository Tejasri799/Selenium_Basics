package Day_4;

public class College_one {

static String str[][]={{"11", "Ankia"},{"12", "Shivaay"},{"13", "Omkara"},{"14", "Teju"},{"15", "Rudra"}};
static int marks[][]={{11,94,96,0},{12,49,40,0},{13,58,44,0},{14,88,96,0},{15,67,96,0}};

public  float calc_avg(int i, int j)
{
	float avg=(i+j)/2.0f;
	return avg;
}
public static  int search (String i2)
{
	int index;
	int id = Integer.parseInt(i2);
	for(int i=0; i<=4; i++)
	{
		if(id==marks[i][0])
		{
			index=i;
			break;
		}
	}
	return id;
}

	public static void main(String[] args) {
		College_one p = new College_one();
		System.out.println(" ID " +" NAME " + " AVG ");
		for(int i=0; i<p.str.length; i++)
		{
			int k = search("12");
			if(k==marks[i][0])
			{
				float j;
			
		 	j = p.calc_avg(marks[i][1], marks[i][2]);
		 	System.out.println(str[i][0] + " "+ str[i][1] + " " + j);
		
		
		
	}
	
}
	}
}
	
		
