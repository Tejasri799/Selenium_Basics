package Day_4;

public class College {
	public static void main(String[] args) {
		int i;
		float f;
		student lovely = new student(90, 84, 76);
//		lovely.java = 90;
//		lovely.selenium = 84;
//		lovely.sql = 76;
		lovely.calc_avg();
		System.out.println(lovely.avg);
		
		student Anika = new student(96, 98, 99);
//		Anika.java = 96;
//		Anika.selenium = 98;
//		Anika.sql = 99;
		Anika.calc_avg();
		System.out.println(Anika.avg);
	}
}
	