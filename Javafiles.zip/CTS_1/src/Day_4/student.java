package Day_4;

public class student {
		int id;
		String name;
		int selenium;
		int java;
		int sql;
		float avg;
		public student(int selenium,int java,int sql)
		{
			System.out.println("Object Created is Avg of the student");
			this.java=java;
			this.selenium=selenium;
			this.sql=sql;
		}
		public void calc_avg()
		{
			avg=(selenium + java + sql)/3.0f;
		}
}