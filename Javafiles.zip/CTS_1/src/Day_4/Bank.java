package Day_4;

public class Bank {
		public float get_Roi(){
			return 9.5f;
		}


}
