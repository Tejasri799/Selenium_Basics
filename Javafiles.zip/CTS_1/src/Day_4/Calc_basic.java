package Day_4;

public class Calc_basic {
	public int add(int x, int y)
	{
		int z= x+y;
		System.out.println("2 Parameters");
	    return z;
	}
	public int add(int a, int b, int c)
	{
		int d =a+b+c;
		System.out.println("3 Parameters");
		return d;
	}
	public static void main(String[] args) {
		Calc_basic g = new Calc_basic();
		int sum = g.add(5,6);
		int plus = g.add(2, 5,8);
		System.out.println(sum);
		System.out.println(plus);
		
	}
	

}
