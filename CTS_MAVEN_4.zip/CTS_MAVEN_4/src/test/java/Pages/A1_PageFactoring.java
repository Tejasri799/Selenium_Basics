package Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class A1_PageFactoring 
{
	WebDriver dr;
	@FindBy(xpath = "//input[@ id='user-name']")
	WebElement Uname;
	@FindBy(xpath = "//input[@ id='password']")
	WebElement pwd;
	@FindBy(xpath = "//input[@ value ='LOGIN']")
	WebElement btn;
	public A1_PageFactoring(WebDriver dr)
	{
		this.dr = dr;
		PageFactory.initElements(dr,this);
	}
	public void set_uname(String id)
	{
		Uname.sendKeys(id);
	}
	public void set_pwd(String p)
	{
		pwd.sendKeys(p);
	}
	public void clk_btn()
	{
		btn.click();
	}
	public String getTitle()
	{
		String s = dr.getTitle();
		return s;
	}
	public void login(String uid, String pd)
	{
		this.set_uname(uid);
		this.set_pwd(pd);
		this.clk_btn();
	}
	
}
	