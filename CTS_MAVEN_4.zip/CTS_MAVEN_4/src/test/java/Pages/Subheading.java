package Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Subheading
{
	WebDriver dr;
	@FindBy(xpath="//div[@ class = 'product_label']")
	WebElement products;
	
	@FindBy(xpath = "//div[@ class = 'inventory_item_label']//child::div[contains (text(), 'Backpack')]")
	WebElement pname;
	
	public Subheading(WebDriver dr)
	{
		this.dr = dr;
		PageFactory.initElements(dr,this);
	}
	public String getPd()
	{
		String s = products.getText();
		return s;
	}
	public String getpdn()
	{
		String s = pname.getText();
		return s;
	}

}
