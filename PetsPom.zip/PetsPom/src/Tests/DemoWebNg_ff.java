package Tests;

import org.testng.annotations.Test;

import Excel.Excel_1;
import Library.Utilities2;
import Pages.Login;

import javax.swing.text.Utilities;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;

public class DemoWebNg_ff extends Excel_1{
	static WebDriver dr;
	Utilities2 util;
	Excel_1 e;
	//String re = "Your Account has been created. Please try login !!";

@BeforeClass

public void launch(){
	e=new Excel_1();
getExcel("Sheet1");
util = new Utilities2(dr);
util.Logg("Completed reading from Excel");

}

@BeforeMethod
public void A_Webopen()
{
	System.setProperty("webdriver.gecko.driver", "geckodriver.exe");
	dr = new FirefoxDriver();
	dr.get("https://jpetstore.cfapps.io/login");
	dr.manage().window().maximize();
	System.out.println("Firefox browser Launched");
}

@Test(dataProvider="register")
public void B_signIn(String u,String p,String s)
{
	Login z = new Login(dr);
	String s1=z.Loginfunction(u,p);
	Assert.assertTrue(s1.contains(s));
	util.Logg("Login Successful with UserName : " + u + "  and  Password : " + p);
	System.out.println("Login Successful with UserName : " + u + "and  PassWord : " + p);
	dr.close();
}

@DataProvider(name="register")
public String[][] register(){
	return data;
}
}