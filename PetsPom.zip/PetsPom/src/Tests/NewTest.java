package Tests;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import Excel.Excel_1;
import Library.Utilities2;
import Pages.Login;

public class NewTest extends Excel_1 {
	WebDriver dr;
	Utilities2 u2;
	Excel_1 e;
	
	
  @Test
  public void f() {
  }
}
