package Tests;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import Pages.Login;
import Pages.Myprofile;
import Pages.PetSignIn;
import Pages.Signup;

public class PetPom {
	WebDriver dr;
	Signup pp;
	PetSignIn page;
	Login page1;
	Myprofile page2;
	@BeforeClass
	  public void LaunchBrowser()
  	{
	  System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
	  dr = new ChromeDriver();
	  dr.get("https://jpetstore.cfapps.io/catalog");
  	}
	@Test(priority=0)
	public void Ent()
	{
	pp = new Signup(dr);
	String get = pp.Start1();
	Assert.assertTrue(get.contains("J"));
	}
	/* @Test(priority=1)
	  public void Reg()
	  {
		page = new PetSignIn(dr);
		  String Register = page.registration("teju3tejasri@gmail.com","Passion@1997", "Passion@1997", "Tejasri", "M B", "teju3tejasri@gmail.com", "9676395565", "351,Upstairs","New Street" ,"Tirupati", "Andhra Pradesh", "517501", "India");
		  Assert.assertTrue(Register.contains("Tejasri"));
	  }*/

  @Test(priority=2)
	  public void Sign_In()
	  {
		page1 = new Login(dr);
		  String Login_Page= page1.Loginfunction ("teju3tejasri@gmail.com","Passion@1997");
		  
		  Assert.assertTrue(Login_Page.contains("J"));
	  }
  @Test(priority=3)
  public void Readtitle() 
  {
	  page2 = new Myprofile(dr);
	  String get1 = page2.Welcome();
	  Assert.assertTrue(get1.contains("J"));
  }
}
  
  


