package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import Library.Utilities1;
public class Login {
	WebDriver dr;
	Signup s = new Signup(dr); 
	Title t= new Title(dr);
	Utilities1 u;
	public Login(WebDriver dr)
	{
		this.dr=dr;
		u = new Utilities1(dr);
	}
	
	By Uname = By.xpath("//input[@ name='username']");
	By Pass = By.xpath("//input[@ name='password']");
	By Enter = By.xpath("//input[@ id='login']");
	
	public void Username(String log)
	{
		WebElement d = u.EW(Uname,20);
		dr.findElement(Uname).sendKeys(log);
	}
	public void Password(String log)
	{
		WebElement d = u.EW(Pass,20);
		dr.findElement(Pass).sendKeys(log);
	}
	public void clk_Enter()
	{
		WebElement d = u.EW(Enter,20);
		d.click();
	}
	public String Loginfunction(String u,String p)
	{
		this.Username(u);
		this.Password(p);
		this.clk_Enter();
		String s = dr.findElement(By.xpath("//div[@id='WelcomeContent']//child::div")).getText();
		return s;
	}
}