package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import Library.Utilities1;

public class PetSignIn 
{
	WebDriver dr;
	Title t = new Title(dr);
	Signup s = new Signup(dr); 
	Utilities1 u; 
	public PetSignIn(WebDriver dr)
	{
	this.dr = dr;
	u = new Utilities1(dr);
	}
		By user = By.xpath("//input[@id='username']");
		By pass = By.xpath("//input[@id='password']");
		By rpass = By.xpath("//input[@ id ='repeatedPassword']");
		By fname = By.xpath("//input[@id='firstName']");
		By lname = By.xpath("//input[@id='lastName']");
		By email = By.xpath("//input[@id='email']");
		By phone = By.xpath("//input[@id='phone']");
		By add1 = By.xpath("//input[@id='address1']");
		By add2 = By.xpath("//input[@id='address2']");
		By city = By.xpath("//input[@id='city']");
		By state = By.xpath("//input[@id='state']");
		By zip = By.xpath("//input[@id='zip']");
		By country = By.xpath("//input[@id='country']");
		By dp1 = By.xpath("//select[@id='languagePreference']//child::option[1]");
		By dp2 = By.xpath("//select[@id='favouriteCategoryId']//child::option[2]");
		By s1 = By.xpath("//input[@id='listOption1']");
		By s2 = By.xpath("//input[@id='bannerOption1']");
		By save = By.xpath("//input[@ value = 'Save Account Information']");
		
		public void Username(String r)
		{
			WebElement data = u.EW(user,20);
			data.sendKeys(r);
		}
		public void Password(String r)
		{
			WebElement data = u.EW(pass,20);
			dr.findElement(pass).sendKeys(r);
		}
		public void Confirm_Password(String r)
		{
			WebElement data = u.EW(rpass,20);
			dr.findElement(rpass).sendKeys(r);
		}
		public void FirstName(String r)
		{
			WebElement data = u.EW(fname,20);
			dr.findElement(fname).sendKeys(r);
		}
		public void LastName(String r)
		{
			WebElement data = u.EW(lname,20);
			dr.findElement(lname).sendKeys(r);
		}
		public void Email(String r)
		{
			WebElement data = u.EW(email,20);
			dr.findElement(email).sendKeys(r);
		}
		public void Phone(String r)
		{
			WebElement data = u.EW(phone,20);
			dr.findElement(phone).sendKeys(r);
		}
		public void Address1(String r)
		{
			WebElement data = u.EW(add1,20);
			dr.findElement(add1).sendKeys(r);
		}
		public void Address2(String r)
		{
			WebElement data = u.EW(add2,20);
			dr.findElement(add2).sendKeys(r);
		}
		public void City(String r)
		{
			WebElement data = u.EW(city,20);
			dr.findElement(city).sendKeys(r);
		}
		public void State(String r)
		{
			WebElement data = u.EW(state,20);
			dr.findElement(state).sendKeys(r);
		}
		public void zip(String r)
		{
			WebElement data = u.EW(zip,20);
			dr.findElement(zip).sendKeys(r);
		}
		public void country(String r)
		{
			WebElement data = u.EW(country,20);
			dr.findElement(country).sendKeys(r);
		}
		public void btn1(String r)
		{
			WebElement data = u.EW(dp1, 20);
			dr.findElement(dp1).click();
		}
		public void btn2(String r)
		{
			WebElement data = u.EW(dp2, 20);
			dr.findElement(dp2).click();
		}
		public void select1(String r)
		{
			WebElement data = u.EW(s1, 20);
			dr.findElement(s1).click();
		}
		public void select2(String r)
		{
			WebElement data = u.EW(s2, 20);
			dr.findElement(s2).click();
		}
		public String registration(String un, String p, String cp, String fn, String ln, String em, String ph, String a1, String a2, String c, String st, String zip, String co)
		{
			this.Username(un);
			this.Password(p);
			this.Confirm_Password(cp);
			this.FirstName(fn);
			this.LastName(ln);
			this.Email(em);
			this.Phone(ph);
			this.Address1(a1);
			this.Address2(a2);
			this.City(c);
			this.State(st);
			this.zip(zip);
			this.country(co);
			dr.findElement(dp1).click();
			dr.findElement(dp2).click();
			dr.findElement(s1).click();
			dr.findElement(s2).click();
			dr.findElement(save).click();
			
			u.Screenshot();
			String s = dr.getTitle();
			return s;
		}
			
	}

		
		
		
		
		

		

/*		dr.findElement(By.xpath("//input[@id='username']")).sendKeys("teju3tejasri@gmail.com");
dr.findElement(By.xpath("//input[@id='password']")).sendKeys("Passion@1997");
dr.findElement(By.xpath("//input[@ id ='repeatedPassword']")).sendKeys("Passion@1997");
dr.findElement(By.xpath("//input[@id='firstName']")).sendKeys("Tejasri");
dr.findElement(By.xpath("//input[@id='lastName']")).sendKeys("M B");
dr.findElement(By.xpath("//input[@id='email']")).sendKeys("teju3tejasri@gmail.com");
dr.findElement(By.xpath("//input[@id='phone']")).sendKeys("9676395565");
dr.findElement(By.xpath("//input[@id='address1']")).sendKeys("351, upstairs");
dr.findElement(By.xpath("//input[@id='address2']")).sendKeys("New Street");
dr.findElement(By.xpath("//input[@id='city']")).sendKeys("Tirupati");
dr.findElement(By.xpath("//input[@id='state']")).sendKeys("Andhra Pradesh");
dr.findElement(By.xpath("//input[@id='zip']")).sendKeys("517501");
dr.findElement(By.xpath("//input[@id='country']")).sendKeys("India");
dr.findElement(By.xpath("//select[@id='languagePreference']//child::option[1]")).click();
dr.findElement(By.xpath("//select[@id='favouriteCategoryId']//child::option[2]")).click();
dr.findElement(By.xpath("//input[@id='listOption1']")).click();
dr.findElement(By.xpath("//input[@id='bannerOption1']")).click();
dr.findElement(By.xpath("//input[@ value = 'Save Account Information']")).click();*/














