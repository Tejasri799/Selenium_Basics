package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import Library.Utilities1;

public class Myprofile {
	WebDriver dr;
	Signup s1 = new Signup(dr); 
	Title t = new Title(dr);
	Utilities1 u;
	
		public Myprofile(WebDriver dr)
		{
			this.dr = dr;
		u = new Utilities1(dr);
		}
		By s = By.xpath("//div[@ id='WelcomeContent']//child::div");
		public String Welcome()
		{
			WebElement w = u.EW(s,20);
			 w.getText();
			 u.Screenshot();
			String g = dr.getTitle();
			
			
					return g;
		}
	}


