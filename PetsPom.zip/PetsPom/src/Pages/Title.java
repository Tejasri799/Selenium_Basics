package Pages;

import org.openqa.selenium.WebDriver;

public class Title {
	
	WebDriver dr;
	
	public Title(WebDriver dr)
	{
		this.dr=dr;
		
	}
	public String getTitle()
	{
	String t = dr.getTitle();
	return t;
	}
}
