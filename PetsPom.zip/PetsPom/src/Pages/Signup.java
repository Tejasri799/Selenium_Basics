package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import Library.Utilities1;

public class Signup {
WebDriver dr;
Utilities1 u;
public Signup(WebDriver dr)
{
	this.dr=dr;
	u = new Utilities1(dr);
}
	By clk1 = By.xpath("//div[@ id ='MenuContent']//child::a[2]");
	//By clk2 = By.xpath("//input[@ value ='Login']");
	
	public void clk_Enter1()
	{
		WebElement w = u.EW(clk1,20);
		w.click();
	}
//	public void clk_Enter2()
//	{
//		WebElement w = u.EW(clk2,20);
//		w.click();
//	}
	public String Start1()
	{
		this.clk_Enter1();
		//this.clk_Enter2();
		String t = dr.getTitle();
		return t;
	}
}



