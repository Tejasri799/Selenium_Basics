package Tests;

import javax.swing.text.Utilities;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;


import Library.Utilities2;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;

import Pages.AUT_Login_Page;
import Pages.AUT_Home_Page;

public class Test_AUT_Login3 extends Utilities2 {
  
	static WebDriver dr;
	AUT_Login_Page loginpage;
	AUT_Home_Page homepage;


  @BeforeClass
  public void LaunchBrowser()
  {
	  getExcel();
  }
  @BeforeMethod
  public void Lb1()
  {
	  String URL = "http://demowebshop.tricentis.com/login";
	 dr = lb("Chrome",URL);        //make sure providing the object here (dr)
	  System.out.println("launched");
  }
  @Test(dataProvider = "logindata")
 public void test_login_Page(String id,String p)
 {
	  System.out.println(id);
	  System.out.println(p);
	  loginpage = new AUT_Login_Page(dr);
	  homepage = new AUT_Home_Page(dr);
	  loginpage.do_login(id, p);
	
	  String verify = homepage.get_displayed_eid();
	  Assert.assertTrue(verify.contains("teju3tejasri@gmail.com"));
	  dr.close();
	  
 }
	  @DataProvider(name="logindata")
	  public String[][] logindata(){
	  	return data;
	  }
 

}
