package Tests;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import Pages.A1_PageFactoring;
import Pages.Subheading;

public class PageFactoringNG 
{
	WebDriver dr;
	A1_PageFactoring lp;
	Subheading sps;
	@BeforeClass
	public void LaunchBrowser()
	{
		System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");
		dr = new ChromeDriver();
		dr.get("https://www.saucedemo.com/");
	}
	
  @Test(priority=0)
  public void f() 
  {
	  lp = new A1_PageFactoring(dr);
	  sps = new Subheading(dr);
	  lp.login("standard_user", "secret_sauce");
	  String s = lp.getTitle();
	  Assert.assertTrue(s.contains("Labs"));
  }
  @Test(priority=1)
  public void f1()
  {
	  String x = sps.getPd();
	  Assert.assertTrue(x.contains("Products"));
	  System.out.println(x);
  }
  @Test(priority=2)
  public void f2()
  {
	  String x = sps.getpdn();
	  Assert.assertTrue(x.contains("Backpack"));
	  System.out.println(x);
  }
}

