package Tests;

import org.testng.annotations.Test;
import Library.Utilities;
import Pages.RC1;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;

public class RoyalNG 
{
	WebDriver dr;
	Utilities u;
	RC1 p1;
	
	@BeforeClass
	  public void beforeClass() {
		u = new Utilities(dr);
		dr = u.bb("Chrome");
		p1= new RC1(dr);
		}
	
  @Test(priority=0)
  public void f1()
  {
	  boolean z = p1.Verify1();
	  System.out.println(z);
	  Assert.assertTrue(z);
  }
  @Test(priority=1)
  public void f2() {
	  p1.setup();
  }
  @Test(priority=2)
  public void f3() {
	  boolean z1 = p1.Verify2();
	  System.out.println(z1);
	  Assert.assertTrue(z1);
  }
}
  


