package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class RC1 {
	WebDriver dr;
	public RC1(WebDriver dr) {
		this.dr=dr;
	}
	
	public boolean Verify1() {
		boolean b = dr.findElement(By.xpath("//div[@class='p']//following::a[@ class ='inlineHyperlink'][4]")).isDisplayed();
		return b;
	}
	public void setup()
	{
		dr.findElement(By.xpath("//img[@class='headerMainToolbar__menuButtonImage']")).click();
		dr.findElement(By.xpath("//a[@id='rciHeaderSideNavMenu-1']")).click();
		dr.findElement(By.xpath("//img[@class='headerSidenav__buttonImage']")).click();
		dr.findElement(By.xpath("//a[@id='rciHeaderMenuItem-2']")).click();
		dr.findElement(By.xpath("//img[@class='headerSearchIcon__base__image']")).click();
		dr.findElement(By.xpath("//input[@class='headerSearchBox__input']")).sendKeys("Rhapsody of the Seas");
		dr.findElement(By.xpath("//img[@class='desaturate']")).click();
		dr.findElement(By.xpath("//div[@class='searchResult__title']//child::a[contains(text(),'Deck Plans')]")).click();
		//dr.findElement(By.xpath("//img[@title='Rhapsody of the Seas, Aerial View With Sunset, Canary Islands, Greece, and Croatia Destinations']")).click();
		//dr.findElement(By.xpath("//a[contains(text(),'DECK')]")).click();
		//dr.findElement(By.xpath("//select[@class='deck-dropdown']")).click();
		dr.findElement(By.xpath("//option[@value='BR']")).click();
	}
	public boolean Verify2()
	{
		boolean b1 = dr.findElement(By.xpath("//h4[contains(text(),'Royal Suite')]")).isDisplayed();
		return b1;
		
	}

}
