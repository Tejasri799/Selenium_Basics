package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class RC2 {
	static WebDriver dr;
	
	public void setup()
	{
		dr.get("https://www.royalcaribbean.com/alaska-cruises");
		dr.findElement(By.xpath("//img[@class='headerMainToolbar__menuButtonImage']")).click();
		dr.findElement(By.xpath("//a[@id='rciHeaderSideNavMenu-1']")).click();
		dr.findElement(By.xpath("//img[@class='headerSidenav__buttonImage']")).click();
		dr.findElement(By.xpath("//a[@id='rciHeaderMenuItem-2']")).click();
		dr.findElement(By.xpath("//img[@title='Rhapsody of the Seas, Aerial View With Sunset, Canary Islands, Greece, and Croatia Destinations']")).click();
		dr.findElement(By.xpath("//a[contains(text(),'DECK')]")).click();
		dr.findElement(By.xpath("//select[@class='deck-dropdown']")).click();
		dr.findElement(By.xpath("//option[@value='BR']")).click();
	}
	
public static void main(String[] args) {
		
	System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
	dr = new ChromeDriver();
	RC2 s =new RC2();
	s.setup();
	
}

}
	
	



