package STEP_DEF;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class test2 {
	
	 static WebDriver dr;
	
	@Given("^Browser is launched and login page displayed$")
	public void browser_is_launched_and_login_page_displayed() throws Throwable {
		System.out.println("browser_is_launched_and_login_page_displayed");
		System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
		dr = new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com/login");
	
	    
	}

	@When("^User enters login credentials and clicks on login$")
	public void user_enters_login_credentials_and_clicks_on_login() throws Throwable {
		System.out.println("user_enters_login_credentials_and_clicks_on_login");
		dr.findElement(By.id("Email")).sendKeys("teju3tejasri@gmail.com");
		dr.findElement(By.id("Password")).sendKeys("Passion@1997");
		dr.findElement(By.xpath("//input[@class='button-1 login-button']")).click();
	   
	}

	@Then("^Successful login happens & profile name displayed correctly$")
	public void successful_login_happens_profile_name_displayed_correctly() throws Throwable {
		System.out.println("successful_login_happens_profile_name_displayed_correctly");
		String t = dr.findElement(By.xpath("//div[@class='header-links']//child::li[1]")).getText();
		if(t.equals("teju3tejasri@gmail.com"))
		{
			System.out.println("Pass");
		}
		else
		{
			System.out.println("Fail");
		}
	   
	}

}
