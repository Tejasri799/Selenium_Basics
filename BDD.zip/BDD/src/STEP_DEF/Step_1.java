package STEP_DEF;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Step_1 {
	/*@Given("^Browser is launched and login page displayed$")
	public void browser_is_launched_and_login_page_displayed() throws Throwable {
	   System.out.println("browser_is_launched_and_login_page_displayed");
	   System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
	   
	}

	@When("^User enters login credentials and clicks on login$")
	public void user_enters_login_credentials_and_clicks_on_login() throws Throwable {
	   System.out.println("user_enters_login_credentials_and_clicks_on_login");
	}

	@Then("^Successful login happens & profile name displayed correctly$")
	public void successful_login_happens_profile_name_displayed_correctly() throws Throwable {
	  System.out.println("successful_login_happens_profile_name_displayed_correctly"); 
	}*/

}
