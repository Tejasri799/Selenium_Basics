package Maven_5;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class Practice {
  @Test
  public void f() {
	  System.out.println("in testing");
	  System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");
	  WebDriver dr = new ChromeDriver();
	  dr.get("https://jpetstore.cfapps.io/catalog");
  }
}
