package Maven;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

public class Screenshot {
	static int counter=1;
	static WebDriver dr;
	public Screenshot(WebDriver dr)
	{
		this.dr=dr;
	}
	public void getScreenshot()
	{
		String path = "C:\\Users\\BLTuser.BLT0188\\Desktop\\SCREENSHOTS";
		String filename = counter + ".png";
		File f1 = ((TakesScreenshot)dr).getScreenshotAs(OutputType.FILE);
		File f2 = new File(path+filename);
		
		try {
			FileUtils.copyFile(f1, f2);
		}
		catch (IOException e)
		{
			System.out.println("screen shot no : " + counter + " failed");
			e.printStackTrace();
		}
		counter++;
	}

}
