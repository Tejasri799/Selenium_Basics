package Maven;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Driverfactory {
	public static WebDriver launch_browser(String browser, String url)
	{
		WebDriver dr = null;
		switch(browser)
		{
		case "CHROME":
			System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");
			dr = new ChromeDriver();
			break;
		case "FIREFOX" :
			System.out.println("webdriver.gecko.driver","gecho");
		}
	}

}
