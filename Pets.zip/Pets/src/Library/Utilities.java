package Library;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Utilities
{
/*	WebDriver dr;
	int counter=1;
	
	public Utilities(WebDriver dr)
	{
		this.dr=dr;
	}
	public WebElement w(By locator, int timeout)
	{
		WebElement d= null;
	
	try {
		WebDriverWait wait = new WebDriverWait(dr,timeout);
	
		
	}
	
	}
*/
}


