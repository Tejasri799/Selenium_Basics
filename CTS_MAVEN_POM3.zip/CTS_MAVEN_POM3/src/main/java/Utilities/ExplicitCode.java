package Utilities;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class ExplicitCode {

	protected static WebDriver dr;
	static int counter=1;
	
	public void launch_browser(String url,String browser) {
		if(browser.contains("chrome")) {
			String s="src\\test\\resources\\DRIVERS\\chromedriver_v79.exe";
		System.setProperty("webdriver.chrome.driver",s);
		dr=new ChromeDriver();
		dr.get(url);
		dr.manage().window().maximize();
	}
		else
			if(browser.contains("FIREFOX")){
			String s1="src\\test\\resources\\DRIVERS\\geckodriver.exe";
			System.setProperty("webdriver.gecko.driver",s1);
			dr=new FirefoxDriver();
			dr.get(url);
			dr.manage().window().maximize();
			
		}

	}}
