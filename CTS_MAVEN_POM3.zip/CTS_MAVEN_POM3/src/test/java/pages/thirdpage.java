package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class thirdpage {
	WebDriver dr;

	public thirdpage() {
		this.dr=dr;
	}
	By per=By.xpath("//ul[@class='nav nav-pills pull-right']//li[2]");
	By ad=By.xpath("//ul[@class='tag-list']//li");
	By ac=By.xpath("//span[@id='316743-label']");
	By di=By.xpath("//span[@id='317709-label']");
	By out=By.xpath("//span[@id='316861-label']");
	By fi=By.xpath("/html/body/div/div/div[3]/div/span/button");
	
	public void person() {
		dr.findElement(per).click();
		
	}
	public void add() {
		dr.findElement(ad).click();
	}
	public void acq() {
		dr.findElement(ac).click();
	}
	public void digi() {
		dr.findElement(di).click();
	}
	public void outreach() {
		dr.findElement(out).click();;
	}
	public void finish() {
		dr.findElement(fi).click();
	}
	public  void adding() {
		this.person();
		this.add();
		this.acq();
		this.digi();
		this.outreach();
		this.finish();
	}
}
