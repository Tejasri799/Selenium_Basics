package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import Utilities.ExplicitCode;

public class firstpage {
	WebDriver dr;
	ExplicitCode e;
	public firstpage() {
		this.dr=dr;
		e= new ExplicitCode();
	}
//	By Id=By.xpath("/html/body/div/form[1]/div/div/div[1]/div[3]/div/div/div/div[2]/div[2]/div/input[1]");
	
	public void tile() {
		System.out.println("in tile");
		dr.findElement(By.xpath("/html/body/div/form[1]/div/div/div[1]/div[3]/div/div/div/div[2]/div[2]/div/input[1]")).sendKeys("845133@cognizant.com");
		
	}
	

}
