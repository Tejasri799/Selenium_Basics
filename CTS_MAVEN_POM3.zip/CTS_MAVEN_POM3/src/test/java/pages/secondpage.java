package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import Utilities.ExplicitCode;

public class secondpage {
  
	WebDriver dr;
	ExplicitCode e;
	public secondpage() {
		this.dr=dr;
		e= new ExplicitCode();
		
	}
	By id=By.xpath("//input[@name='UserName']");
	By pass=By.xpath("//input[@name='Password']");
	By log=By.xpath("//input[@class='desktopsubmit']");
	By lo=By.xpath("//input[@class='btn btn-block']");
	
	public void username(String us) {
		dr.findElement(id).sendKeys(us);
	}
	public void password(String pwd) {
		dr.findElement(pass).sendKeys(pwd);
	}
	public void logon() {
		dr.findElement(log).click();
	}
	public void lo() {
		dr.findElement(lo).click();
	}
	public void login(String us,String pwd) {
		
		this.username(us);
		this.password(pwd);
		this.logon();
		this.lo();
	}
	
}
