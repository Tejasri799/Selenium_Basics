package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Inthirdpage {
	WebDriver dr;
	public Inthirdpage() {
		this.dr=dr;
	}
	
	By a=By.xpath("//ul[@class='tag-list']//li[1]");
	By d=By.xpath("//ul[@class='tag-list']//li[2]");
	By o=By.xpath("//ul[@class='tag-list']//li[3]");

	
	public String ac() {
	String c1=	dr.findElement(a).getText();
	return c1;
	}
	public String d() {
	String c2=	dr.findElement(d).getText();
	return c2;
	}
	public String o() {
		String c3= dr.findElement(o).getText();
		return c3;
	}
	public void delete() {
		dr.findElement(a).click();
	}
	
	public void checking() {
		this.ac();
		this.d();
		this.o();
		this.delete();
	}

}
