package tests;

import org.openqa.selenium.By;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import Utilities.ExplicitCode;
import pages.Inthirdpage;
import pages.firstpage;
import pages.secondpage;
import pages.thirdpage;

public class NewTest1 extends ExplicitCode{
	firstpage fp;
	secondpage sp;
	thirdpage tp;
	Inthirdpage itp;
	@BeforeClass
	public void launcbrowser() {
		System.out.println("launching the browser");
		launch_browser("https://be.cognizant.com/","chrome");
		
	}
  @Test(priority=0)
  public void f() {
	  System.out.println("in F");
	  fp=new firstpage();
	  System.out.println("inn");
	  dr.findElement(By.xpath("/html/body/div/form[1]/div/div/div[1]/div[3]/div/div/div/div[2]/div[2]/div/input[1]")).sendKeys("845133@cognizant.com");
	  fp.tile();
  }
  @Test(priority=1)
  public void f1() {
	  System.out.println("In F1 test");
	  sp=new secondpage();
	  sp.login("845133", "Jupiter@5");
  }
  @Test(priority=2)
  public void f2() {
	  System.out.println("In f3 test");
	  tp=new thirdpage();
	  tp.adding();
  }
  @Test(priority=3)
  public void f3() {
	  System.out.println("in f3 test");
	  itp=new Inthirdpage();
	  itp.checking();
  }
  
}
