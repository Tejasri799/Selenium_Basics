package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class AUT_Login_Page
{
	By uid = By.xpath("//input[@ id = 'Email']");
	By pwd = By.xpath("//input[@ id = 'Password']");
	By btn = By.xpath("//input[@ class = 'button-1 login-button']");
	WebDriver dr;
	public AUT_Login_Page(WebDriver dr)
	{
		this.dr = dr;
	}
	public void set_uid(String id)
	{
		dr.findElement(uid).sendKeys(id);
	}
	public void set_pwd(String p)
	{
		dr.findElement(pwd).sendKeys(p);
	}
	public void clk_btn()
	{
		dr.findElement(btn).click();
	}
	public void do_login(String id, String p)
	{
		this.set_uid(id);
		this.set_pwd(p);
		this.clk_btn();
	
	}
	public String get_title()
	{
		String k = dr.getTitle();
		System.out.println(k);
		return k;
	}

}
