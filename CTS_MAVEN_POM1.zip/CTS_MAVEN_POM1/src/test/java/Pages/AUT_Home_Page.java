package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class AUT_Home_Page 
{
	WebDriver dr;
	By profile_xp = By.xpath("//div[@class='header']//div[2]//child::li[1]//child::a");
	public AUT_Home_Page(WebDriver dr)
	{
		this.dr = dr;
	}
	public String get_displayed_eid()
	{
		System.out.println(profile_xp);
		return dr.findElement(profile_xp).getText();
	}

}
