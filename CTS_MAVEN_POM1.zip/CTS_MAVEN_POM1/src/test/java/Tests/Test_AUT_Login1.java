package Tests;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

import Library.Utilities2;

import org.testng.annotations.BeforeClass;

import Pages.AUT_Login_Page;
import Pages.AUT_Home_Page;

public class Test_AUT_Login1 extends Utilities2{
	WebDriver dr;
	AUT_Login_Page loginpage;
	AUT_Home_Page homepage;
	//Utilities2 z;

  @BeforeClass
  public void LaunchBrowser()
  {
	 lb("Chrome","http://demowebshop.tricentis.com/login");
	  System.out.println("All done");
  }
  /*public void LaunchBrowser()
  	{
	  System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
	  dr = new ChromeDriver();
	  dr.get("http://demowebshop.tricentis.com/login");
  	}*/

  @Test(priority=0)
  public void Test_Login_Page()
  {
	  loginpage = new AUT_Login_Page(dr);
	  String Login_Page_Title = loginpage.get_title();
	  Assert.assertTrue(Login_Page_Title.contains("Shop"));
  }
  
  @Test(priority=2)
  public void Test_Home_Page()
  {
	  loginpage.do_login("teju3tejasri@gmail.com","passion@1997");
	  homepage = new AUT_Home_Page(dr);
	  String Actual_eid = homepage.get_displayed_eid();
	  Assert.assertTrue(Actual_eid.contains("teju3tejasri@gmail.com"));
  }
  
}
